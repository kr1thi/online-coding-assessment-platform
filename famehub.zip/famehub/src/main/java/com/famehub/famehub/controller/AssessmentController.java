package com.famehub.famehub.controller;

import com.famehub.famehub.dto.AssessmentRequest;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import com.famehub.famehub.dto.QuestionDTO;
import com.famehub.famehub.entity.*;
import com.famehub.famehub.repository.*;
import com.famehub.famehub.service.AssessmentExcelService;
import com.famehub.famehub.service.AssessmentService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.transaction.Transactional;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/assessment")
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
public class AssessmentController {

    @Autowired private AssessmentService assessmentService;
    @Autowired private AssessmentRepository assessmentRepo;
    @Autowired private AssessmentQuestionRepository questionRepo; 
    @Autowired private AssessmentResultRepository resultRepo;
    @Autowired private StudentRepository studentRepo;
    @Autowired private AssessmentExcelService excelService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    @Autowired private UserRepository userRepository;

    // get all assessment
    @GetMapping("/all")
    public ResponseEntity<List<Assessment>> getAllAssessments() {
        return ResponseEntity.ok(assessmentRepo.findAll());
    }
    @PostMapping("/create")
    public ResponseEntity<?> createAssessment(@RequestBody Map<String, Object> payload) {
        try {
            Assessment assessment = new Assessment();
            assessment.setTitle(payload.get("title").toString());
            Integer duration = payload.get("duration") != null ? 
                               Integer.parseInt(payload.get("duration").toString()) : 60;
            assessment.setDuration(duration);
            Assessment saved = assessmentRepo.save(assessment);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error creating assessment: " + e.getMessage());
        }
    }

 // AssessmentController.java
    @GetMapping("/{id}")
    public ResponseEntity<?> getAssessmentWithQuestions(@PathVariable Long id) {
        return assessmentRepo.findById(id).map(assessment -> {
            // Questions ai DTO-kku map panrom
            List<QuestionDTO> questionDTOs = assessment.getQuestions().stream().map(q -> {
                QuestionDTO dto = new QuestionDTO();
                dto.setId(q.getId());
                dto.setTitle(q.getTitle());
                dto.setDescription(q.getDescription());
                dto.setType(q.getType());
                if ("MCQ".equalsIgnoreCase(q.getType())) {
                    dto.setOptions(q.getOptions()); // MCQ kku options 
                } else {
                if ((q.getExampleInput() == null || q.getExampleInput().isEmpty()) && q.getTestCases() != null) {
                    parseJsonToDto(q.getTestCases(), dto);
                } else {
                    dto.setExampleInput(q.getExampleInput());
                    dto.setExampleOutput(q.getExampleOutput());
                }
                }
             
                
                return dto;
            }).toList();

            Map<String, Object> response = new HashMap<>();
            response.put("id", assessment.getId());
            response.put("questions", questionDTOs); // Ippo questions data ready
            return ResponseEntity.ok(response);
        }).orElse(ResponseEntity.notFound().build());
    }
    private void parseJsonToDto(String json, QuestionDTO dto) {
        //  Data null ha iruntha baathu viduvom
        if (json == null || json.trim().isEmpty() || json.trim().equals("[]")) {
            dto.setExampleInput("No input sample available");
            dto.setExampleOutput("No output sample available");
            return;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(json);

            //  root array a,no empty
            if (root.isArray() && root.size() > 0) {
                JsonNode firstNode = root.get(0);
                dto.setExampleInput(firstNode.has("input") ? firstNode.get("input").asText() : "No Input");
                dto.setExampleOutput(firstNode.has("output") ? firstNode.get("output").asText() : "No Output");
            } 
            // Single objectah iruntha
            else if (root.isObject()) {
                dto.setExampleInput(root.has("input") ? root.get("input").asText() : "No Input");
                dto.setExampleOutput(root.has("output") ? root.get("output").asText() : "No Output");
            }
        } catch (Exception e) {
            dto.setExampleInput("Invalid Format");
            dto.setExampleOutput("Invalid Format");
        }
    }
    // 3. RUN CODE (JUDGE0)
    @PostMapping("/run")
    public ResponseEntity<?> runCode(@RequestBody Map<String, Object> payload) {
        try {
            String sourceCode = (String) payload.get("sourceCode");
            Integer languageId = (Integer) payload.get("languageId");
            String stdin = payload.get("stdin") != null ? (String) payload.get("stdin") : "";
            String output = assessmentService.callJudge0(sourceCode, languageId, stdin);
            return ResponseEntity.ok(Map.of("output", output));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("output", "Run Error: " + e.getMessage()));
        }
    }

    //  final submission
    @PostMapping("/final-submit")
    public ResponseEntity<?> finalSubmit(@RequestBody AssessmentRequest request) {
        try {
            //  Process submission (Judge0/Logic)
            Map<String, Object> evaluationResult = assessmentService.processSubmission(request);
            
            //  Result object creation
            AssessmentResult finalRecord = new AssessmentResult();
            
            // Inga request-la varura ID, Student table-oda ID-ah irukkanum
            // User table-oda ID-ah iruntha Unknown Student problem varum
            finalRecord.setStudentId(request.getStudentId()); 
            
            finalRecord.setQuestionId(request.getQuestionId());
            finalRecord.setAssessmentId(request.getAssessmentId());
            finalRecord.setScore(Double.valueOf(evaluationResult.get("score").toString()));
            finalRecord.setStatus((String) evaluationResult.get("status"));
            
            // 3. Save to DB
            resultRepo.save(finalRecord);
            
            return ResponseEntity.ok(evaluationResult);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Submission Failed: " + e.getMessage());
        }
    }

   
    //  add manual method (ui form)
    @PostMapping("/{assessmentId}/add-manual")
    public ResponseEntity<?> addManualQuestion(@PathVariable Long assessmentId, @RequestBody Map<String, Object> payload) {
        try {
            Assessment assessment = assessmentRepo.findById(assessmentId)
                    .orElseThrow(() -> new RuntimeException("Assessment not found"));

            AssessmentQuestion q = new AssessmentQuestion();
            q.setAssessment(assessment);
            q.setTitle(payload.get("challengeName") != null ? payload.get("challengeName").toString() : "Untitled");
            q.setDescription(payload.get("problemStatement") != null ? payload.get("problemStatement").toString() : "");
            String type = payload.get("type") != null ? payload.get("type").toString() : "CODING";
            q.setType(type);

            if ("MCQ".equalsIgnoreCase(type)) {
                // MCQ Logic
                q.setOptions(payload.get("options") != null ? payload.get("options").toString() : "[]");
                q.setCorrectAnswer(payload.get("correctAnswer") != null ? payload.get("correctAnswer").toString() : "");
                q.setTestCases("[]");
            } 
            else {
                // CODING Logic
                q.setConstraints(payload.get("constraints") != null ? payload.get("constraints").toString() : "");
                q.setExampleInput(payload.get("sampleInput") != null ? payload.get("sampleInput").toString() : "");
                q.setExampleOutput(payload.get("sampleOutput") != null ? payload.get("sampleOutput").toString() : "");
                q.setLanguage(payload.get("language") != null ? payload.get("language").toString() : "java");

                if (payload.get("testCases") != null) {
                    q.setTestCases(payload.get("testCases").toString());
                } else {
                    q.setTestCases("[]");
                }
            }

            questionRepo.save(q);
            return ResponseEntity.ok(Map.of("message", type + " saved successfully!"));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error saving to DB: " + e.getMessage());
        }
    }
    @PostMapping("/{assessmentId}/upload")
    public ResponseEntity<?> uploadQuestions(@PathVariable Long assessmentId, @RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("File empty-ah irukku pa!");
            }

            // CSV read panna
            List<AssessmentQuestion> questions = excelService.parseCSV(file.getInputStream());
            
            // Assessment irukka nu check panna
            Assessment assessment = assessmentRepo.findById(assessmentId)
                    .orElseThrow(() -> new RuntimeException("Assessment not found!"));
            
            // Question-ai link panni save panna
            for (AssessmentQuestion q : questions) {
                q.setAssessment(assessment);
            }
            questionRepo.saveAll(questions); // Batch save 
            
            return ResponseEntity.ok("Success: " + questions.size() + " questions uploaded!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }
   

        
    @PostMapping("/{assessmentId}/add-questions")
    public ResponseEntity<?> addQuestions(
        @PathVariable Long assessmentId, 
        @RequestBody Map<String, Object> requestPayload
    ) {
        try {
            //  Safe parsing for questionIds (handle andles Integer/Long automatically)
            List<?> rawIds = (List<?>) requestPayload.get("questionIds");
            List<Long> questionIds = rawIds.stream()
                                           .map(obj -> Long.valueOf(obj.toString()))
                                           .collect(Collectors.toList());

            // Safe parsing for manualOptionsMap
            Map<String, List<String>> rawMap = (Map<String, List<String>>) requestPayload.get("manualOptionsMap");
            Map<Long, List<String>> manualOptionsMap = new HashMap<>();
            
            if (rawMap != null) {
                rawMap.forEach((k, v) -> manualOptionsMap.put(Long.valueOf(k), v));
            }

            assessmentService.addQuestionsToAssessment(assessmentId, questionIds, manualOptionsMap);
            
            return ResponseEntity.ok("Questions assigned successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(400).body("Error: " + e.getMessage());
        }
    }
    
    @GetMapping("/teacher/{assessmentId}/results")
    public ResponseEntity<?> getAssessmentResults(@PathVariable Long assessmentId) {
        List<AssessmentResult> results = resultRepo.findByAssessmentId(assessmentId);
        long totalQuestions = questionRepo.countByAssessmentId(assessmentId);
        
        Map<Long, Map<String, Object>> studentSummary = new HashMap<>();

        for (AssessmentResult res : results) {
            // Null check -->its important(crash)
            Long sId = res.getStudentId();
            if (sId == null) continue; 
            
            studentSummary.computeIfAbsent(sId, k -> {
                Map<String, Object> summary = new HashMap<>();
                summary.put("studentId", sId);
              
                String name = studentRepo.findByUserId(sId)
                        .map(Student::getName) 
                        .orElse("Student " + sId); 

                summary.put("studentName", name);
                summary.put("totalScore", 0.0);
                summary.put("questionsAttempted", 0);
                summary.put("totalPossible", totalQuestions);
                return summary;
            });

            Map<String, Object> summary = studentSummary.get(sId);
            
            double questionScore = (res.getScore() != null ? res.getScore() : 0.0) / 100.0;
            double currentTotal = (double) summary.get("totalScore");
            
            summary.put("totalScore", currentTotal + questionScore);
            
            int attempted = (int) summary.get("questionsAttempted");
            summary.put("questionsAttempted", attempted + 1);
            
            // Status-a update panna
            summary.put("status", res.getStatus());
        }
        
        return ResponseEntity.ok(studentSummary.values());
    }
    @PostMapping("/finish")
    public ResponseEntity<?> finishAssessment(@RequestBody Map<String, Object> payload) {
        try {
            Long studentId = Long.parseLong(payload.get("studentId").toString());
            Long assessmentId = Long.parseLong(payload.get("assessmentId").toString());
            
          
            return ResponseEntity.ok(Map.of("message", "Test submitted successfully!"));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
    
    @GetMapping("/student/{studentId}/results")
    public ResponseEntity<?> getStudentResults(@PathVariable Long studentId) {
        return ResponseEntity.ok(resultRepo.findByStudentId(studentId));
    }
}