package com.famehub.famehub.controller;

import java.io.*;

import java.util.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.famehub.famehub.repository.StudentRepository;
import com.famehub.famehub.entity.Problem;
import com.famehub.famehub.entity.Assessment;
import com.famehub.famehub.entity.AssessmentQuestion;
import com.famehub.famehub.repository.ProblemRepository;
import com.famehub.famehub.repository.SubmissionRepository;
import com.famehub.famehub.repository.AssessmentQuestionRepository;
import com.famehub.famehub.repository.AssessmentRepository;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {

    @Autowired private ProblemRepository problemRepository;
    @Autowired private SubmissionRepository submissionRepository;
    @Autowired private AssessmentQuestionRepository assessmentQuestionRepository;
    @Autowired private AssessmentRepository assessmentRepository;
    @Autowired private StudentRepository studentRepo;
    //  create assessment (Card create panna)
    @PostMapping("/assessment/add")
    public ResponseEntity<?> createAssessment(@RequestBody Assessment assessment) {
        try {
            // Frontend la irundhu title and duration varum
            Assessment saved = assessmentRepository.save(assessment);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error creating assessment: " + e.getMessage());
        }
    }

    //  get all assessment dropdown and student card ku
    @GetMapping("/assessment/all")
    public ResponseEntity<?> getAllAssessments() {
        try {
            return ResponseEntity.ok(assessmentRepository.findAll());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching assessments: " + e.getMessage());
        }
    }

    // bulk upload link
    @PostMapping("/bulk-upload")
    @Transactional
    public ResponseEntity<?> bulkUploadCSV(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "assessmentId", required = false) Long assessmentId) {
        
        if (file.isEmpty()) return ResponseEntity.badRequest().body("File is empty");

        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            CsvToBean<Problem> csvToBean = new CsvToBeanBuilder<Problem>(reader)
                    .withType(Problem.class)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();

            List<Problem> problems = csvToBean.parse();
            // Teacher assigned questions to a specific assessment card
            if (assessmentId != null && assessmentId > 0) {
                Assessment targetAssessment = assessmentRepository.findById(assessmentId)
                        .orElseThrow(() -> new RuntimeException("Assessment not found!"));

                List<AssessmentQuestion> assessmentQuestions = new ArrayList<>();
                for (Problem p : problems) {
                    AssessmentQuestion aq = new AssessmentQuestion();
                    aq.setTitle(p.getChallengeName());
                    aq.setDescription(p.getProblemStatement());
                    aq.setConstraints(p.getConstraints());
                    aq.setTemplate(p.getSolution()); // Inga solution templateah ulla pōgum
                    aq.setType("CODING");
                    aq.setAssessment(targetAssessment); // Mapping logic
                    assessmentQuestions.add(aq);
                }
                assessmentQuestionRepository.saveAll(assessmentQuestions);
                return ResponseEntity.ok("Questions successfully linked to: " + targetAssessment.getTitle());
            } 
            
            // public Practice Pool - visible to everyone in practice section
            else {
                for (Problem p : problems) {
                    p.setIsAssessment(false);
                    p.setAssessmentId(null);
                }
                problemRepository.saveAll(problems);
                return ResponseEntity.ok("Successfully uploaded to Public Practice (Problem table)!");
            }

        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
 // AdminController.java-la add pannirukan
    @DeleteMapping("/assessment/{id}")
    @Transactional
    public ResponseEntity<?> deleteAssessment(@PathVariable Long id) {
        try {
            //  Intha assessmentku kela irukura questions-ai delete panna
            // Repositoryla deleteByAssessmentId(id) create panna
            assessmentQuestionRepository.deleteByAssessmentId(id);
            
            // Assessment card-ai delete panna
            assessmentRepository.deleteById(id);
            
            return ResponseEntity.ok("Assessment deleted successfully!");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
    @GetMapping("/assessment/public/all")
    public ResponseEntity<?> getPublicAssessments() {
        return ResponseEntity.ok(assessmentRepository.findAll());
    }

    // admin stats
    @GetMapping("/stats")
    public ResponseEntity<?> getAdminStats() {
        try {
            Map<String, Object> stats = new HashMap<>();
            long assessmentCardsCount = assessmentRepository.count();
            long practiceCount = problemRepository.countByIsAssessment(false);

            stats.put("totalAssessments", assessmentCardsCount); 
            stats.put("totalPractice", practiceCount);
            stats.put("totalSubmissions", submissionRepository.count());
            stats.put("activeStudents", studentRepo.count()); // Futurela studentRepo.count()
            
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Stats Error: " + e.getMessage());
        }
    }

    @GetMapping("/submissions/all")
    public ResponseEntity<?> getAllSubmissions() {
        return ResponseEntity.ok(submissionRepository.findAll());
    }
}